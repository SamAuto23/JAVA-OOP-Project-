package Shop;


public enum KeyboardType {
	STANDARD,
	FLEXIBLE,
	GAMING

}
