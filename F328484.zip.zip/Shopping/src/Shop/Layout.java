package Shop;

public enum Layout {
    US,
    UK
}
