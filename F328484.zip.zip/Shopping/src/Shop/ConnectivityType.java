package Shop;
public enum ConnectivityType {
    WIRED,
    WIRELESS;

   
}
