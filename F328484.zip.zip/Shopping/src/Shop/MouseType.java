package Shop;

public enum MouseType {
STANDARD,
GAMING
}
