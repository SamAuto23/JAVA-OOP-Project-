package Shop;
public enum ProductCategory {
    MOUSE,
    KEYBOARD;



}
