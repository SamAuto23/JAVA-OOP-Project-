package Shop;

public abstract class Product {
    private int barcode;
    private String brand;
    private String color;
    private ConnectivityType connectivity;
    private int quantityInStock;
    private double originalCost;
    private double retailPrice;
    private ProductCategory category;

    public Product(int barcode, String brand, String color, ConnectivityType connectivity, int quantityInStock, double originalCost, double retailPrice, ProductCategory category) {
        if (barcode <= 0 || brand == null || color == null || connectivity == null || category == null) {
            throw new IllegalArgumentException("Invalid product attributes");
        }
        this.barcode = barcode;
        this.brand = brand;
        this.color = color;
        this.connectivity = connectivity;
        this.quantityInStock = quantityInStock;
        this.originalCost = originalCost;
        this.retailPrice = retailPrice;
        this.category = category;
    }

    // Getters and Setters
    public int getBarcode() {
        return barcode;
    }

    public String getBrand() {
        return brand;
    }

    public String getColor() {
        return color;
    }

    public ConnectivityType getConnectivity() {
        return connectivity;
    }

    public int getQuantityInStock() {
        return quantityInStock;
    }

    public void setQuantityInStock(int quantityInStock) {
        if (quantityInStock < 0) {
            throw new IllegalArgumentException("Quantity in stock cannot be negative");
        }
        this.quantityInStock = quantityInStock;
    }

    public double getOriginalCost() {
        return originalCost;
    }

    public double getRetailPrice() {
        return retailPrice;
    }

    public ProductCategory getCategory() {
        return category;
    }

    // Abstract method to be implemented by subclasses
    public abstract String displayWithoutCost();

    public static Product fromString(String line) throws IllegalArgumentException {
        //System.out.println("Parsing line: " + line); // Debugging line

        String[] parts = line.split(", ");
        if (parts.length != 10) {
            throw new IllegalArgumentException("Insufficient data to parse product. Parts: " + parts.length);
        }

        try {
            int barcode = Integer.parseInt(parts[0]);
            ProductCategory category = ProductCategory.valueOf(parts[1].toUpperCase());
            String type = parts[2].trim().toUpperCase();
            String brand = parts[3];
            String color = parts[4];
            ConnectivityType connectivity = ConnectivityType.valueOf(parts[5].toUpperCase());
            int quantity = Integer.parseInt(parts[6].trim());
            double originalCost = Double.parseDouble(parts[7]);
            double retailPrice = Double.parseDouble(parts[8]);
            String additionalInfo = parts[9];

            switch (category) {
                case KEYBOARD:
                    Layout layout = Layout.valueOf(additionalInfo.toUpperCase());
                    KeyboardType keyboardType = KeyboardType.valueOf(type);
                    return new Keyboard(barcode, brand, color, connectivity, quantity, originalCost, retailPrice, category, layout, keyboardType);
                case MOUSE:
                    int buttons = Integer.parseInt(additionalInfo);
                    MouseType mouseType = MouseType.valueOf(type);
                    return new Mouse(barcode, brand, color, connectivity, quantity, originalCost, retailPrice, category, buttons, mouseType);
                default:
                    throw new IllegalArgumentException("Unknown product category: " + category);
            }
        } catch ( ArrayIndexOutOfBoundsException | IllegalArgumentException e) {
            throw new IllegalArgumentException("Error parsing product details: " + e.getMessage(), e);
        }
    }

    @Override
    public String toString() {
        String additionalInfo;
        String type;
        if (this instanceof Keyboard) {
            Keyboard keyboard = (Keyboard) this;
            additionalInfo = keyboard.getLayout().toString();
            type = keyboard.getType().toString();
        } else if (this instanceof Mouse) {
            Mouse mouse = (Mouse) this;
            additionalInfo = Integer.toString(mouse.getNumberOfButtons());
            type = mouse.getType().toString();
        } else {
            additionalInfo = "unknown";
            type = "unknown";
        }
        return String.format("%d, %s, %s, %s, %s, %s, %d, %.2f, %.2f, %s",
                barcode, category.toString().toLowerCase(), type.toLowerCase(), brand, color, connectivity.toString().toLowerCase(),
                quantityInStock, originalCost, retailPrice, additionalInfo);
    }
}
